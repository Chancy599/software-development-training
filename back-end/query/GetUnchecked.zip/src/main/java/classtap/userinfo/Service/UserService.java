package classtap.userinfo.Service;

import classtap.userinfo.Pojo.ClassSchedule;


import java.util.List;

public interface UserService {

    public List<ClassSchedule> GetUncheckedList(String userId);
}
