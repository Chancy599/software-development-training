package classtap.userinfo.Service.impl;

import classtap.userinfo.Mapper.ClassScheduleMapper;

import classtap.userinfo.Pojo.ClassSchedule;

import classtap.userinfo.Service.UserService;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;

import java.util.List;

@Service
public class UserServiceImpl implements UserService {


    @Autowired
    private ClassScheduleMapper classScheduleMapper;

    public List<ClassSchedule> GetUncheckedList(String userId) {
        return classScheduleMapper.GetUncheckedList(userId);

}
}
