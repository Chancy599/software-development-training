package classtap.userinfo.controller;

import classtap.userinfo.Pojo.ClassSchedule;

import classtap.userinfo.Service.UserService;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.web.bind.annotation.*;

import java.util.List;

@RestController
public class UserController {

    @Autowired
    private UserService userservice;

    @GetMapping("/GetUncheckedList")
    public List<ClassSchedule> GetUncheckedList(String userId){
        return userservice.GetUncheckedList(userId);
    }
}
