package com.scut.entities;

import lombok.Data;

@Data
public class EnterIdToSelectClass {
    private String classId;
    private int total;
}