create
    definer = `mysql.sys`@localhost procedure recycle_bin_recycle_table(IN recycle_table varchar(64))
    deterministic
    sql security invoker
    modifies sql data
BEGIN DECLARE v_db_name VARCHAR(64); DECLARE v_table_name VARCHAR(64); SELECT ORIGIN_SCHEMA INTO v_db_name FROM mysql.recycle_bin_info WHERE TABLE_NAME = recycle_table; SELECT ORIGIN_TABLE INTO v_table_name FROM mysql.recycle_bin_info WHERE TABLE_NAME = recycle_table; SET @sys.tmp.recycle_bin_recycle_table.sql = CONCAT('RENAME TABLE `', '__cdb_recycle_bin__', '`.`',  recycle_table, '` TO `' , v_db_name, '`.`', v_table_name, '`'); PREPARE stmt_recycle_table FROM @sys.tmp.recycle_bin_recycle_table.sql; EXECUTE stmt_recycle_table; DEALLOCATE PREPARE stmt_recycle_table; END;

