create
    definer = `mysql.sys`@localhost procedure recycle_bin_purge_table(IN recycle_table varchar(64))
    deterministic
    sql security invoker
    modifies sql data
BEGIN SET @sys.tmp.recycle_bin_purge_table.sql = CONCAT('DROP TABLE `', '__cdb_recycle_bin__', '`.`', recycle_table, '`'); PREPARE stmt_drop_table FROM @sys.tmp.recycle_bin_purge_table.sql; EXECUTE stmt_drop_table; DEALLOCATE PREPARE stmt_drop_table; END;

